#Requires AutoHotkey v2.0
#SingleInstance Force
CoordMode "Mouse", "Screen"
CoordMode "Pixel", "Screen"

; Separate Fortnite menu-loop macro by Krstic.
; It only runs at 1920x1080 and searches supplied PLAY AGAIN and lobby PLAY images.

requiredImages := [
    A_ScriptDir "\images\PlayAgainLeaveTeam.png",
    A_ScriptDir "\images\PlayAgainNormal.png",
    A_ScriptDir "\images\PlayAgain.png",
    A_ScriptDir "\images\PlayAgainLabelLeaveTeam.png",
    A_ScriptDir "\images\PlayAgainLabelNormal.png",
    A_ScriptDir "\images\PlayAgainLabel.png",
    A_ScriptDir "\images\LobbyPlay.png",
    A_ScriptDir "\images\PirateShopAccess.png",
    A_ScriptDir "\images\TreasureFoundHeader.png",
    A_ScriptDir "\images\TreasureFoundText.png",
    A_ScriptDir "\images\PlayAgainNoTeam.png",
    A_ScriptDir "\images\ReturnToLobby.png",
    A_ScriptDir "\images\WaitingForPlayers.png"
]
for imagePath in requiredImages {
    if !FileExist(imagePath) {
        MsgBox "The macro image files are missing. Right-click the ZIP, choose Extract All, then run Fortnite Queue Loop.ahk from the extracted folder with its images folder beside it.", "Extract the macro first", "Icon!"
        ExitApp
    }
}
if !FileExist(A_ScriptDir "\SendScreenshotWebhook.ps1") || !FileExist(A_ScriptDir "\Settings.ps1") {
    MsgBox "A helper file is missing. Extract the ZIP first, then keep both PowerShell helper files beside Fortnite Queue Loop.ahk.", "Extract the macro first", "Icon!"
    ExitApp
}
if (A_ScreenWidth != 1920 || A_ScreenHeight != 1080) {
    MsgBox "Fortnite Queue Loop requires a 1920 x 1080 display. Current display: " A_ScreenWidth " x " A_ScreenHeight ".", "Resolution required", "Icon!"
    ExitApp
}

running := false
lastActionKind := ""
lastActionAt := 0
imageVariation := 55
gamesCompleted := 0
sessionStart := 0
sessionElapsedMs := 0
webhookUrl := ""
discordUserId := ""
notifyEachGame := false
sendSummaryOnStop := true
tokenNoticeEnabled := true
rewardBannerVisible := false
rewardConfirmCount := 0
leaveEnabled := true
lowSquadScans := 0
leaveState := 0
leaveStateAt := 0
lastButtonClickAt := 0
lastSquadCount := -1
crashRecoveryEnabled := true
fortniteWasRunning := false
restartAttempts := 0
restartDueAt := 0
lastRestartAt := 0
randomKeysEnabled := false
paused := false
randomKeyRemainingMs := 0
randomKeyHeld := ""
randomKeyHoldMs := 0
randomKeyHeldUntil := 0
randomKeyList := ["Space", "Space", "Space", "w", "a", "s", "d"]
rng := Random

statsGui := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20", "Fortnite session stats")
statsGui.BackColor := "173B6C"
statsGui.SetFont("s8 Bold cD9E7F5", "Segoe UI")
statsGui.AddText("x10 y8 w240 h18 Center", "FORTNITE SESSION")
statsGui.SetFont("s10 Bold cFFFFFF", "Segoe UI")
statsState := statsGui.AddText("x10 y29 w240 h20 Center", "STOPPED")
statsGui.SetFont("s9 cFFFFFF", "Segoe UI")
statsGames := statsGui.AddText("x10 y52 w240 h18 Center", "Games completed: 0")
statsRuntime := statsGui.AddText("x10 y72 w240 h18 Center", "Running time: 00:00:00")
statsAction := statsGui.AddText("x10 y91 w240 h20 Center", "Action: idle")
statsSquad := statsGui.AddText("x10 y111 w240 h18 Center", "Party remaining: --")

app := Gui("", "Fortnite Queue Loop | By Krstic")
app.BackColor := "F3F6FA"
app.MarginX := 18
app.MarginY := 16
app.SetFont("s17 Bold c173B6C", "Segoe UI")
app.AddText("w360 h30", "FORTNITE QUEUE LOOP")
app.SetFont("s9 c637184", "Segoe UI")
app.AddText("w360 h38", "Clicks PLAY AGAIN in either results layout, or PLAY in the lobby. It ignores STAY WITH TEAM.")
startButton := app.AddButton("x18 y100 w116 h36", "Start (F9)")
startButton.OnEvent("Click", StartLoop)
pauseButton := app.AddButton("x142 y100 w108 h36 Disabled", "Pause (F11)")
pauseButton.OnEvent("Click", PauseResume)
stopButton := app.AddButton("x260 y100 w108 h36 Disabled", "Stop (F10)")
stopButton.OnEvent("Click", StopLoop)
app.SetFont("s9 c243247", "Segoe UI")
statusLabel := app.AddText("x18 y146 w360 h38", "Ready · Focus Fortnite, then start the loop.")
statsMainLabel := app.AddText("x18 y184 w360 h22", "Games: 0    Runtime: 00:00:00")
app.SetFont("s9 Bold c173B6C", "Segoe UI")
app.AddText("x18 y215 w360 h20", "DISCORD WEBHOOK  (OPTIONAL)")
app.SetFont("s8 c637184", "Segoe UI")
app.AddText("x18 y238 w360 h18", "Saved encrypted on this PC when you click Save, Test Photo, or Start.")
webhookInput := app.AddEdit("x18 y259 w180 h28 Password", "")
saveSettingsButton := app.AddButton("x202 y258 w72 h30", "Save")
saveSettingsButton.OnEvent("Click", SaveWebhookSettings)
testWebhookButton := app.AddButton("x280 y258 w98 h30", "Test Photo")
testWebhookButton.OnEvent("Click", TestWebhook)
app.SetFont("s8 c637184", "Segoe UI")
app.AddText("x18 y292 w360 h18", "Discord user ID to ping (optional; Test Photo includes a ping)")
discordUserIdInput := app.AddEdit("x18 y311 w360 h26", "")
savedSettings := LoadSavedSettings()
webhookInput.Value := savedSettings["webhook"]
discordUserIdInput.Value := savedSettings["userId"]

gameNotifyCheckbox := app.AddCheckbox("x18 y343 w360 h22", "Send a Discord message for each finished game")
tokenNotifyCheckbox := app.AddCheckbox("x18 y367 w360 h22 Checked", "Screenshot + Discord alert on treasure rewards")
crashRecoveryCheckbox := app.AddCheckbox("x18 y391 w360 h22 Checked", "Relaunch Fortnite if it closes")
summaryCheckbox := app.AddCheckbox("x18 y415 w360 h22 Checked", "Send a session summary to Discord when stopped")
randomKeysCheckbox := app.AddCheckbox("x18 y439 w360 h22", "Hold keys · jump more often (Space / W / A / S / D)")
leaveWhenSoloCheckbox := app.AddCheckbox("x18 y463 w360 h22 Checked", "Leave + requeue when fewer than 2 party members remain")
savedPrefs := StrSplit(savedSettings["prefs"], ",")
gameNotifyCheckbox.Value := savedPrefs.Length >= 1 ? savedPrefs[1] + 0 : 0
tokenNotifyCheckbox.Value := savedPrefs.Length >= 2 ? savedPrefs[2] + 0 : 1
crashRecoveryCheckbox.Value := savedPrefs.Length >= 3 ? savedPrefs[3] + 0 : 1
summaryCheckbox.Value := savedPrefs.Length >= 4 ? savedPrefs[4] + 0 : 1
randomKeysCheckbox.Value := savedPrefs.Length >= 5 ? savedPrefs[5] + 0 : 0
leaveWhenSoloCheckbox.Value := savedPrefs.Length >= 6 ? savedPrefs[6] + 0 : 1
app.SetFont("s8 c8793A3", "Segoe UI")
app.AddText("x18 y491 w360 h18 Center", "BY KRSTIC  |  1920 × 1080 ONLY")
app.OnEvent("Close", CloseApp)
app.Show("w400 h526")
Hotkey "F9", StartLoop, "On"
Hotkey "F10", StopLoop, "On"
Hotkey "F11", PauseResume, "On"

StartLoop(*) {
    global app, running, paused, startButton, stopButton, pauseButton, statusLabel, lastActionKind
    global gamesCompleted, sessionStart, sessionElapsedMs, webhookUrl, discordUserId, notifyEachGame, sendSummaryOnStop
    global randomKeysCheckbox, randomKeysEnabled, randomKeyRemainingMs, randomKeyHeldUntil, rng, statsAction
    global webhookInput, discordUserIdInput, gameNotifyCheckbox, tokenNotifyCheckbox, crashRecoveryCheckbox, summaryCheckbox, randomKeysCheckbox, leaveWhenSoloCheckbox, testWebhookButton, saveSettingsButton
    global tokenNoticeEnabled, rewardBannerVisible, crashRecoveryEnabled, fortniteWasRunning
    global leaveWhenSoloCheckbox, leaveEnabled, lowSquadScans, leaveState, leaveStateAt, lastButtonClickAt, lastSquadCount
    global restartAttempts, restartDueAt, lastRestartAt
    if (A_ScreenWidth != 1920 || A_ScreenHeight != 1080) {
        statusLabel.Text := "Stopped: display must be exactly 1920 x 1080."
        return
    }
    if (running)
        return
    if (Trim(discordUserIdInput.Value) != "" && !RegExMatch(Trim(discordUserIdInput.Value), "^\d{17,20}$")) {
        statusLabel.Text := "Discord user ID must be 17–20 digits, or leave it blank."
        return
    }
    if (Trim(webhookInput.Value) != "" && !RegExMatch(Trim(webhookInput.Value), "^https://(discord\.com|discordapp\.com)/api/webhooks/\d+/[A-Za-z0-9._-]+")) {
        statusLabel.Text := "Webhook URL format looks invalid. Check it or clear the field."
        return
    }
    webhookUrl := Trim(webhookInput.Value)
    discordUserId := Trim(discordUserIdInput.Value)
    if (!PersistSettings(webhookUrl, discordUserId)) {
        statusLabel.Text := "Could not save webhook settings on this PC. Check PowerShell access."
        return
    }
    running := true
    paused := false
    lastActionKind := ""
    gamesCompleted := 0
    sessionElapsedMs := 0
    sessionStart := A_TickCount
    notifyEachGame := gameNotifyCheckbox.Value
    sendSummaryOnStop := summaryCheckbox.Value
    randomKeysEnabled := randomKeysCheckbox.Value
    randomKeyRemainingMs := 0
    randomKeyHeld := ""
    randomKeyHoldMs := 0
    randomKeyHeldUntil := 0
    tokenNoticeEnabled := tokenNotifyCheckbox.Value
    rewardBannerVisible := false
    rewardConfirmCount := 0
    leaveEnabled := leaveWhenSoloCheckbox.Value
    lowSquadScans := 0
    leaveState := 0
    leaveStateAt := 0
    lastButtonClickAt := 0
    lastSquadCount := -1
    crashRecoveryEnabled := crashRecoveryCheckbox.Value
    fortniteWasRunning := ProcessExist("FortniteClient-Win64-Shipping.exe") > 0
    restartAttempts := 0
    restartDueAt := 0
    lastRestartAt := 0
    startButton.Enabled := false
    stopButton.Enabled := true
    pauseButton.Enabled := true
    pauseButton.Text := "Pause (F11)"
    webhookInput.Enabled := false
    discordUserIdInput.Enabled := false
    saveSettingsButton.Enabled := false
    gameNotifyCheckbox.Enabled := false
    tokenNotifyCheckbox.Enabled := false
    crashRecoveryCheckbox.Enabled := false
    summaryCheckbox.Enabled := false
    randomKeysCheckbox.Enabled := false
    leaveWhenSoloCheckbox.Enabled := false
    testWebhookButton.Enabled := false
    statusLabel.Text := "Running · F11 pauses/resumes. F10 stops."
    SetTimer ScanScreen, 1000
    if (randomKeysEnabled)
        SetTimer RandomKeyTick, 25
    SetTimer UpdateStats, 1000
    ShowStatsOverlay()
    UpdateStats()
    if WinActive("ahk_id " app.Hwnd)
        WinMinimize "ahk_id " app.Hwnd
}

StopLoop(*) {
    global running, paused, startButton, stopButton, pauseButton, statusLabel, statsState, statsAction
    global webhookInput, discordUserIdInput, gameNotifyCheckbox, tokenNotifyCheckbox, crashRecoveryCheckbox, summaryCheckbox, randomKeysCheckbox, leaveWhenSoloCheckbox, testWebhookButton, saveSettingsButton
    global sessionStart, sessionElapsedMs, webhookUrl, sendSummaryOnStop, randomKeyHeldUntil
    wasRunning := running
    SetTimer ScanScreen, 0
    SetTimer RandomKeyTick, 0
    ReleaseRandomKey()
    randomKeyHeldUntil := 0
    SetTimer UpdateStats, 0
    if (wasRunning)
        sessionElapsedMs := A_TickCount - sessionStart
    running := false
    startButton.Enabled := true
    stopButton.Enabled := false
    pauseButton.Enabled := false
    pauseButton.Text := "Pause (F11)"
    paused := false
    webhookInput.Enabled := true
    discordUserIdInput.Enabled := true
    saveSettingsButton.Enabled := true
    gameNotifyCheckbox.Enabled := true
    tokenNotifyCheckbox.Enabled := true
    crashRecoveryCheckbox.Enabled := true
    summaryCheckbox.Enabled := true
    randomKeysCheckbox.Enabled := true
    leaveWhenSoloCheckbox.Enabled := true
    testWebhookButton.Enabled := true
    statsState.Text := "STOPPED"
    statsAction.Text := "Action: idle"
    statusLabel.Text := "Stopped. Games completed: " gamesCompleted "."
    UpdateStats()
    if (wasRunning && sendSummaryOnStop && webhookUrl != "")
        SendWebhook("Fortnite Queue Loop stopped. Games completed: " gamesCompleted ". Runtime: " FormatRuntime(sessionElapsedMs) ".")
}


RandomKeyTick() {
    global running, paused, randomKeysEnabled, randomKeyList, rng, statsAction
    global randomKeyHeld, randomKeyHoldMs, randomKeyHeldUntil
    if (!running || !randomKeysEnabled)
        return
    if (paused) {
        statsAction.Text := "Action: paused"
        return
    }

    ; Never send gameplay keys to a different application.
    try {
        if (!InStr(WinGetProcessName("A"), "FortniteClient")) {
            ReleaseRandomKey()
            randomKeyHeldUntil := 0
            statsAction.Text := "Action: waiting for Fortnite"
            return
        }
    } catch {
        ReleaseRandomKey()
        randomKeyHeldUntil := 0
        statsAction.Text := "Action: waiting for Fortnite"
        return
    }

    now := A_TickCount
    if (randomKeyHeld != "" && now < randomKeyHeldUntil) {
        statsAction.Text := "Action: holding " (randomKeyHeld = "Space" ? "Space (jump)" : StrUpper(randomKeyHeld)) " · " Ceil((randomKeyHeldUntil - now) / 1000) "s"
        return
    }

    ; Release the previous key and press the next one in the same timer tick: no idle pause.
    if (randomKeyHeld != "")
        ReleaseRandomKey()
    StartRandomKey(now)
}

StartRandomKey(now := 0) {
    global randomKeyHeld, randomKeyHoldMs, randomKeyHeldUntil, randomKeyList, rng, statsAction
    if (!now)
        now := A_TickCount
    randomKeyHeld := randomKeyList[rng(1, randomKeyList.Length)]
    randomKeyHoldMs := rng(1, 3) * 1000
    randomKeyHeldUntil := now + randomKeyHoldMs
    statsAction.Text := "Action: holding " (randomKeyHeld = "Space" ? "Space (jump)" : StrUpper(randomKeyHeld)) " · " randomKeyHoldMs // 1000 "s"
    Send("{" randomKeyHeld " down}")
}
ReleaseRandomKey() {
    global randomKeyHeld, randomKeyHoldMs
    if (randomKeyHeld != "") {
        Send("{" randomKeyHeld " up}")
        randomKeyHeld := ""
    }
    randomKeyHoldMs := 0
}
PauseResume(*) {
    global running, paused, pauseButton, statusLabel, statsState, statsAction
    if (!running)
        return
    paused := !paused
    if (paused) {
        ReleaseRandomKey()
        pauseButton.Text := "Resume (F11)"
        statsState.Text := "PAUSED"
        statsAction.Text := "Action: paused"
        statusLabel.Text := "Paused. Press F11 or Resume to continue."
    } else {
        pauseButton.Text := "Pause (F11)"
        statsState.Text := "RUNNING"
        statsAction.Text := "Action: waiting for next key"
        statusLabel.Text := "Running · Activate Fortnite. F11 pauses; F10 stops."
    }
}
CloseApp(*) {
    StopLoop()
    ExitApp()
}

ShowStatsOverlay() {
    global statsGui
    x := Max(0, A_ScreenWidth - 270)
    statsGui.Show("NoActivate x" x " y130 w260 h140")
}

UpdateStats(*) {
    global running, paused, gamesCompleted, sessionStart, sessionElapsedMs, statsState
    global statsGames, statsRuntime, statsMainLabel, statsSquad, lastSquadCount
    if (running) {
        elapsed := A_TickCount - sessionStart
        statsState.Text := paused ? "PAUSED" : "RUNNING"
    } else {
        elapsed := sessionElapsedMs
        statsState.Text := "STOPPED"
    }
    duration := FormatRuntime(elapsed)
    statsGames.Text := "Games completed: " gamesCompleted
    statsRuntime.Text := "Running time: " duration
    statsSquad.Text := lastSquadCount < 0 ? "Party remaining: warming up" : "Party remaining: " lastSquadCount " / 4"
    statsMainLabel.Text := "Games: " gamesCompleted "    Runtime: " duration
}

FormatRuntime(milliseconds) {
    totalSeconds := Floor(milliseconds / 1000)
    hours := Floor(totalSeconds / 3600)
    minutes := Floor(Mod(totalSeconds, 3600) / 60)
    seconds := Mod(totalSeconds, 60)
    return Format("{:02}:{:02}:{:02}", hours, minutes, seconds)
}

TestWebhook(*) {
    global webhookInput, discordUserIdInput, statusLabel
    url := Trim(webhookInput.Value)
    if (url = "") {
        statusLabel.Text := "Paste your Discord webhook URL first."
        return
    }
    if (!RegExMatch(url, "^https://(discord\.com|discordapp\.com)/api/webhooks/\d+/[A-Za-z0-9._-]+")) {
        statusLabel.Text := "Webhook URL format looks invalid. Check it and try Test Photo again."
        return
    }
    userId := Trim(discordUserIdInput.Value)
    if (userId != "" && !RegExMatch(userId, "^\d{17,20}$")) {
        statusLabel.Text := "Discord user ID must be 17–20 digits, or leave it blank."
        return
    }
    if (!PersistSettings(url, userId)) {
        statusLabel.Text := "Could not save webhook settings on this PC. Check PowerShell access."
        return
    }
    if (SendScreenshotWebhook("Fortnite Queue Loop screenshot test.", userId, url))
        statusLabel.Text := "Screenshot test sent to Discord."
}

SaveWebhookSettings(*) {
    global webhookInput, discordUserIdInput, statusLabel
    url := Trim(webhookInput.Value)
    userId := Trim(discordUserIdInput.Value)
    if (url != "" && !RegExMatch(url, "^https://(discord\.com|discordapp\.com)/api/webhooks/\d+/[A-Za-z0-9._-]+")) {
        statusLabel.Text := "Webhook URL format looks invalid. Check it and try Save again."
        return
    }
    if (userId != "" && !RegExMatch(userId, "^\d{17,20}$")) {
        statusLabel.Text := "Discord user ID must be 17–20 digits, or leave it blank."
        return
    }
    if (PersistSettings(url, userId))
        statusLabel.Text := "Settings saved on this PC."
    else
        statusLabel.Text := "Could not save webhook settings on this PC. Check PowerShell access."
}

PersistSettings(url, userId) {
    global gameNotifyCheckbox, tokenNotifyCheckbox, crashRecoveryCheckbox, summaryCheckbox, randomKeysCheckbox, leaveWhenSoloCheckbox
    prefs := gameNotifyCheckbox.Value "," tokenNotifyCheckbox.Value "," crashRecoveryCheckbox.Value "," summaryCheckbox.Value "," randomKeysCheckbox.Value "," leaveWhenSoloCheckbox.Value
    EnvSet("FORTNITE_QUEUE_SETTINGS_PREFS", prefs)
    EnvSet("FORTNITE_QUEUE_SETTINGS_WEBHOOK", url)
    EnvSet("FORTNITE_QUEUE_SETTINGS_USER_ID", userId)
    command := 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' A_ScriptDir '\Settings.ps1" -Mode Save'
    try {
        exitCode := RunWait(command, A_ScriptDir, "Hide")
    } catch {
        exitCode := -1
    }
    EnvSet("FORTNITE_QUEUE_SETTINGS_WEBHOOK", "")
    EnvSet("FORTNITE_QUEUE_SETTINGS_USER_ID", "")
    EnvSet("FORTNITE_QUEUE_SETTINGS_PREFS", "")
    return exitCode = 0
}

LoadSavedSettings() {
    command := 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' A_ScriptDir '\Settings.ps1" -Mode Load'
    try {
        shell := ComObject("WScript.Shell")
        process := shell.Exec(command)
        output := process.StdOut.ReadAll()
        if (process.ExitCode != 0)
            return Map("webhook", "", "userId", "", "prefs", "")
        values := StrSplit(output, "`n")
        webhook := values.Length >= 1 ? Trim(values[1], "`r") : ""
        userId := values.Length >= 2 ? Trim(values[2], "`r") : ""
        prefs := values.Length >= 3 ? Trim(values[3], "`r") : ""
        return Map("webhook", webhook, "userId", userId, "prefs", prefs)
    } catch {
        return Map("webhook", "", "userId", "", "prefs", "")
    }
}

SendScreenshotWebhook(message, userId := "", url := "") {
    global webhookUrl, statusLabel
    if (url = "")
        url := webhookUrl
    if (!RegExMatch(url, "^https://(discord\.com|discordapp\.com)/api/webhooks/\d+/[A-Za-z0-9._-]+")) {
        statusLabel.Text := "Webhook URL format looks invalid. Check it and try Test again."
        return false
    }
    if (userId != "" && !RegExMatch(userId, "^\d{17,20}$")) {
        statusLabel.Text := "Discord user ID must be 17–20 digits, or leave it blank."
        return false
    }
    EnvSet("FORTNITE_QUEUE_WEBHOOK", url)
    EnvSet("FORTNITE_QUEUE_USER_ID", userId)
    EnvSet("FORTNITE_QUEUE_MESSAGE", message)
    command := 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' A_ScriptDir '\SendScreenshotWebhook.ps1"'
    try {
        exitCode := RunWait(command, A_ScriptDir, "Hide")
    } catch {
        exitCode := -1
    }
    EnvSet("FORTNITE_QUEUE_WEBHOOK", "")
    EnvSet("FORTNITE_QUEUE_USER_ID", "")
    EnvSet("FORTNITE_QUEUE_MESSAGE", "")
    if (exitCode = 0)
        return true
    statusLabel.Text := "Screenshot upload failed. Check the webhook, internet connection, and PowerShell."
    return false
}

SendWebhook(message, url := "") {
    global webhookUrl, statusLabel
    if (url = "")
        url := webhookUrl
    if (!RegExMatch(url, "^https://(discord\.com|discordapp\.com)/api/webhooks/\d+/[A-Za-z0-9._-]+")) {
        statusLabel.Text := "Webhook URL format looks invalid. Check it and try Test again."
        return false
    }
    try {
        request := ComObject("WinHttp.WinHttpRequest.5.1")
        request.SetTimeouts(3000, 3000, 5000, 5000)
        if (InStr(url, "?"))
            url .= "&wait=true"
        else
            url .= "?wait=true"
        request.Open("POST", url, false)
        request.SetRequestHeader("Content-Type", "application/json")
        quote := Chr(34)
        backslash := Chr(92)
        safeMessage := StrReplace(message, backslash, backslash . backslash)
        safeMessage := StrReplace(safeMessage, quote, backslash . quote)
        safeMessage := StrReplace(safeMessage, "`r", backslash . "r")
        safeMessage := StrReplace(safeMessage, "`n", backslash . "n")
        body := "{" . quote . "content" . quote . ":" . quote . safeMessage . quote . "," . quote . "allowed_mentions" . quote . ":{" . quote . "parse" . quote . ":[]}}"
        request.Send(body)
        if (request.Status >= 200 && request.Status < 300)
            return true
        statusLabel.Text := "Discord returned HTTP " request.Status ". Check the webhook URL."
    } catch {
        statusLabel.Text := "Could not reach Discord. Check the URL and internet connection."
    }
    return false
}

ScanScreen() {
    global running, paused, statusLabel, lastActionKind, lastActionAt, gamesCompleted
    global notifyEachGame, webhookUrl, discordUserId, tokenNoticeEnabled, rewardBannerVisible, rewardConfirmCount
    global crashRecoveryEnabled, fortniteWasRunning, restartAttempts, restartDueAt, lastRestartAt
    global leaveEnabled, lowSquadScans, leaveState, leaveStateAt, lastButtonClickAt, lastSquadCount
    if (!running)
        return
    if (paused)
        return
    foundX := 0, foundY := 0, foundW := 0, foundH := 0
    if (A_ScreenWidth != 1920 || A_ScreenHeight != 1080) {
        StopLoop()
        return
    }

    gameProcessRunning := ProcessExist("FortniteClient-Win64-Shipping.exe") > 0
    if (gameProcessRunning) {
        fortniteWasRunning := true
        restartDueAt := 0
        if (lastRestartAt && A_TickCount - lastRestartAt >= 120000) {
            restartAttempts := 0
            lastRestartAt := 0
        }
    } else if (fortniteWasRunning && crashRecoveryEnabled) {
        if (restartAttempts >= 3) {
            statusLabel.Text := "Auto-relaunch stopped after 3 tries. Check Epic Games Launcher; F10 stops the macro."
            return
        }
        if (restartDueAt = 0) {
            restartDueAt := A_TickCount + 8000
            statusLabel.Text := "Fortnite closed. Trying to reopen it in 8 seconds..."
            if (webhookUrl != "")
                SendWebhook("Fortnite closed. The macro is attempting to relaunch it.")
            return
        }
        if (A_TickCount >= restartDueAt) {
            try {
                Run("com.epicgames.launcher://apps/fn%3A4fe75bbc5a674f4f9b356b5c90567da5%3AFortnite?action=launch&silent=true")
                restartAttempts += 1
                lastRestartAt := A_TickCount
                restartDueAt := A_TickCount + 45000
                statusLabel.Text := "Asked Epic Games Launcher to reopen Fortnite (" restartAttempts "/3)."
            } catch {
                restartAttempts += 1
                lastRestartAt := A_TickCount
                restartDueAt := A_TickCount + 45000
                statusLabel.Text := "Could not reopen Fortnite. Check Epic Games Launcher (" restartAttempts "/3)."
            }
            return
        }
        statusLabel.Text := "Waiting for Fortnite to reopen..."
        return
    }

    try {
        activeProcess := WinGetProcessName("A")
    } catch {
        statusLabel.Text := "Waiting for Fortnite to be active."
        return
    }
    if (!InStr(activeProcess, "FortniteClient")) {
        statusLabel.Text := "Waiting for Fortnite · active app: " activeProcess ". F10 stops the loop."
        return
    }

    rewardVisible := FindTreasureReward(&tokenX, &tokenY, &tokenW, &tokenH)
    if (rewardVisible) {
        rewardConfirmCount += 1
        if (!rewardBannerVisible && rewardConfirmCount >= 2) {
            rewardBannerVisible := true
            if (tokenNoticeEnabled && webhookUrl != "")
                SendScreenshotWebhook("Fortnite Queue Loop: treasure reward detected!", discordUserId)
        }
    } else {
        rewardConfirmCount := 0
        rewardBannerVisible := false
    }

    warmup := FindWarmupScreen()
    lastSquadCount := warmup ? -1 : CountAliveSquadMembers()
    UpdateStats()

    if (leaveState = 1) {
        if (FindButton("return", &foundX, &foundY, &foundW, &foundH)) {
            Click foundX + foundW // 2, foundY + foundH // 2
            leaveState := 2
            leaveStateAt := A_TickCount
            lastActionKind := ""
            statusLabel.Text := "Selected Return to lobby."
        } else if (A_TickCount - leaveStateAt > 15000) {
            leaveState := 0
            lowSquadScans := 0
            statusLabel.Text := "Could not find Return to lobby; watching the squad again."
        }
        return
    }
    if (leaveState = 2) {
        if (FindButton("lobby", &foundX, &foundY, &foundW, &foundH)) {
            leaveState := 0
            lowSquadScans := 0
            lastActionKind := ""
        } else if (A_TickCount - leaveStateAt >= 2500) {
            Send "{Enter}"
            leaveState := 3
            leaveStateAt := A_TickCount
            statusLabel.Text := "Confirming return to lobby."
            return
        } else {
            statusLabel.Text := "Waiting for the leave confirmation."
            return
        }
    }
    if (leaveState = 3) {
        if (FindButton("lobby", &foundX, &foundY, &foundW, &foundH)) {
            leaveState := 0
            lowSquadScans := 0
            lastActionKind := ""
        } else if (A_TickCount - leaveStateAt > 20000) {
            leaveState := 0
            lowSquadScans := 0
            statusLabel.Text := "Return did not finish; F10 stops the macro."
            return
        } else {
            statusLabel.Text := "Returning to lobby..."
            return
        }
    }

    if (leaveEnabled && !warmup && lastSquadCount = 1) {
        lowSquadScans += 1
        statusLabel.Text := "One squad member detected · confirming " lowSquadScans "/30."
        if (lowSquadScans >= 30) {
            if (FindButton("return", &foundX, &foundY, &foundW, &foundH)) {
                Click foundX + foundW // 2, foundY + foundH // 2
                leaveState := 2
                leaveStateAt := A_TickCount
                lastActionKind := ""
                statusLabel.Text := "Selected Return to lobby."
            } else {
                Send "{Escape}"
                leaveState := 1
                leaveStateAt := A_TickCount
                lastActionKind := ""
                statusLabel.Text := "One squad member remains · opening leave menu."
            }
            lowSquadScans := 0
        }
        return
    }
    lowSquadScans := 0
    sameActionVisible := false
    if (lastActionKind != "") {
        stillVisible := FindButton(lastActionKind, &foundX, &foundY, &foundW, &foundH)
        if (stillVisible) {
            sameActionVisible := true
            if (A_TickCount - lastActionAt < 2500)
                return
        } else {
            lastActionKind := ""
        }
    }

    if (FindButton("again", &foundX, &foundY, &foundW, &foundH)) {
        if (!(sameActionVisible && lastActionKind = "again")) {
            gamesCompleted += 1
            UpdateStats()
            if (notifyEachGame && webhookUrl != "")
                SendWebhook("Fortnite Queue Loop: finished game " gamesCompleted ". Runtime: " FormatRuntime(A_TickCount - sessionStart) ".")
        }
        Click foundX + foundW // 2, foundY + foundH // 2
        lastActionKind := "again"
        lastActionAt := A_TickCount
        statusLabel.Text := "Clicked PLAY AGAIN · completed " gamesCompleted " game(s)."
    } else if (FindButton("lobby", &foundX, &foundY, &foundW, &foundH)) {
        Click foundX + foundW // 2, foundY + foundH // 2
        lastActionKind := "lobby"
        lastActionAt := A_TickCount
        statusLabel.Text := "Clicked lobby PLAY. Waiting for matchmaking."
    } else {
        statusLabel.Text := warmup ? "Warm-up detected · squad check paused." : "Running · Watching squad and menu buttons."
    }
}

FindWarmupScreen() {
    try {
        return ImageSearch(&x, &y, 780, 125, 1150, 205, "*70 " A_ScriptDir "\images\WaitingForPlayers.png")
    } catch {
        return false
    }
}

CountAliveSquadMembers() {
    ; Count health bars in the four fixed squad HUD slots from the supplied detector.
    count := 0
    for y in [790, 840, 900, 1000] {
        hits := 0
        for x in [75, 80, 85] {
            color := PixelGetColor(x, y, "RGB")
            red := (color >> 16) & 0xFF
            green := (color >> 8) & 0xFF
            blue := color & 0xFF
            if ((green > 35 && green > red * 1.2 && green > blue * 1.05)
                || (red > 75 && red > green * 1.3 && red > blue * 1.1))
                hits += 1
        }
        if (hits >= 2)
            count += 1
    }
    return count
}
FindTreasureReward(&foundX, &foundY, &foundW, &foundH) {
    foundW := 0, foundH := 0
    ; Require the actual transparent YOU FOUND text, with tight color tolerance.
    ; The broad PirateShopAccess image matched ordinary lobby scenes, so it is not used as an alert trigger.
    try {
        if (ImageSearch(&foundX, &foundY, 430, 280, 1490, 500, "*35 *TransFF00FF " A_ScriptDir "\images\TreasureFoundText.png")) {
            foundW := 285
            foundH := 68
            return true
        }
    } catch {
    }
    return false
}
FindButton(kind, &foundX, &foundY, &foundW, &foundH) {
    global imageVariation
    foundW := 0
    foundH := 0
    if (kind = "again") {
        x1 := 1120, y1 := 120, x2 := 1918, y2 := 900
        images := [
            [A_ScriptDir "\images\PlayAgainLeaveTeam.png", 360, 70, 65],
            [A_ScriptDir "\images\PlayAgainNormal.png", 360, 70, 65],
            [A_ScriptDir "\images\PlayAgain.png", 482, 89, 65],
            [A_ScriptDir "\images\PlayAgainNoTeam.png", 481, 89, 65],
            [A_ScriptDir "\images\PlayAgainLabelLeaveTeam.png", 250, 44, 90],
            [A_ScriptDir "\images\PlayAgainLabelNormal.png", 250, 44, 90],
            [A_ScriptDir "\images\PlayAgainLabel.png", 258, 45, 90]
        ]
    } else if (kind = "return") {
        x1 := 1200, y1 := 120, x2 := 1880, y2 := 300
        images := [[A_ScriptDir "\images\ReturnToLobby.png", 195, 55, 70]]
    } else {
        x1 := 70, y1 := 800, x2 := 520, y2 := 1010
        images := [[A_ScriptDir "\images\LobbyPlay.png", 328, 80, 65]]
    }
    for image in images {
        variation := image.Length >= 4 ? image[4] : imageVariation
        try {
            if (ImageSearch(&foundX, &foundY, x1, y1, x2, y2, "*" variation " " image[1])) {
                foundW := image[2]
                foundH := image[3]
                return true
            }
        } catch {
            continue
        }
    }
    return false
}



















