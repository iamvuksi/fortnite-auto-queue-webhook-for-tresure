$ErrorActionPreference = 'Stop'
$capturePath = Join-Path $env:TEMP ("FortniteQueue-" + [guid]::NewGuid().ToString('N') + '.png')
$bitmap = $null
$graphics = $null
$client = $null
$multipart = $null
$filePart = $null
$jsonPart = $null
$response = $null
$exitCode = 0

try {
    $webhookUrl = $env:FORTNITE_QUEUE_WEBHOOK
    $userId = $env:FORTNITE_QUEUE_USER_ID
    $message = $env:FORTNITE_QUEUE_MESSAGE
    if ([string]::IsNullOrWhiteSpace($webhookUrl) -or [string]::IsNullOrWhiteSpace($message)) {
        throw 'Webhook settings are missing.'
    }

    Add-Type -AssemblyName System.Drawing
    Add-Type -AssemblyName System.Net.Http
    $bitmap = [System.Drawing.Bitmap]::new(1920, 1080)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.CopyFromScreen(0, 0, 0, 0, $bitmap.Size)
    $bitmap.Save($capturePath, [System.Drawing.Imaging.ImageFormat]::Png)

    $content = $message
    $allowedMentions = @{ parse = @() }
    if ($userId -match '^\d{17,20}$') {
        $content = "<@$userId> $message"
        $allowedMentions = @{ users = @($userId) }
    }
    $payload = @{ content = $content; allowed_mentions = $allowedMentions } | ConvertTo-Json -Depth 5 -Compress

    $separator = if ($webhookUrl.Contains('?')) { '&' } else { '?' }
    $client = [System.Net.Http.HttpClient]::new()
    $multipart = [System.Net.Http.MultipartFormDataContent]::new()
    $jsonPart = [System.Net.Http.StringContent]::new($payload, [System.Text.Encoding]::UTF8, 'application/json')
    $filePart = [System.Net.Http.ByteArrayContent]::new([System.IO.File]::ReadAllBytes($capturePath))
    $filePart.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::Parse('image/png')
    $multipart.Add($jsonPart, 'payload_json')
    $multipart.Add($filePart, 'files[0]', 'fortnite-screenshot.png')
    $response = $client.PostAsync($webhookUrl + $separator + 'wait=true', $multipart).GetAwaiter().GetResult()
    $response.EnsureSuccessStatusCode()
}
catch {
    $exitCode = 1
}
finally {
    if ($response) { $response.Dispose() }
    if ($filePart) { $filePart.Dispose() }
    if ($jsonPart) { $jsonPart.Dispose() }
    if ($multipart) { $multipart.Dispose() }
    if ($client) { $client.Dispose() }
    if ($graphics) { $graphics.Dispose() }
    if ($bitmap) { $bitmap.Dispose() }
    if (Test-Path -LiteralPath $capturePath) {
        Remove-Item -LiteralPath $capturePath -Force -ErrorAction SilentlyContinue
    }
}

exit $exitCode

