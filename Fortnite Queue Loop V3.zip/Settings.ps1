param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('Load', 'Save')]
    [string]$Mode
)

$ErrorActionPreference = 'Stop'
$settingsDirectory = Join-Path $env:LOCALAPPDATA 'FortniteQueueLoop'
$settingsPath = Join-Path $settingsDirectory 'settings.dat'

try {
    Add-Type -AssemblyName System.Security

    if ($Mode -eq 'Save') {
        $webhookUrl = $env:FORTNITE_QUEUE_SETTINGS_WEBHOOK
        $userId = $env:FORTNITE_QUEUE_SETTINGS_USER_ID
        $prefs = $env:FORTNITE_QUEUE_SETTINGS_PREFS
        if ([string]::IsNullOrEmpty($webhookUrl) -and [string]::IsNullOrEmpty($userId) -and [string]::IsNullOrEmpty($prefs)) {
            if (Test-Path -LiteralPath $settingsPath) {
                Remove-Item -LiteralPath $settingsPath -Force
            }
            exit 0
        }

        [System.IO.Directory]::CreateDirectory($settingsDirectory) | Out-Null
        $plainText = "$webhookUrl`n$userId`n$prefs"
        $plainBytes = [System.Text.Encoding]::UTF8.GetBytes($plainText)
        $protectedBytes = [System.Security.Cryptography.ProtectedData]::Protect(
            $plainBytes,
            $null,
            [System.Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        $encryptedText = [Convert]::ToBase64String($protectedBytes)
        [System.IO.File]::WriteAllText($settingsPath, $encryptedText, [System.Text.Encoding]::ASCII)
        exit 0
    }

    if (-not (Test-Path -LiteralPath $settingsPath)) {
        [Console]::Out.WriteLine('')
        [Console]::Out.WriteLine('')
        [Console]::Out.WriteLine('')
        exit 0
    }

    $encryptedText = [System.IO.File]::ReadAllText($settingsPath, [System.Text.Encoding]::ASCII)
    $protectedBytes = [Convert]::FromBase64String($encryptedText)
    $plainBytes = [System.Security.Cryptography.ProtectedData]::Unprotect(
        $protectedBytes,
        $null,
        [System.Security.Cryptography.DataProtectionScope]::CurrentUser
    )
    $plainText = [System.Text.Encoding]::UTF8.GetString($plainBytes)
    $values = $plainText -split "`n", 3
    for ($i = 0; $i -lt 3; $i++) {
        if ($i -lt $values.Count) { [Console]::Out.WriteLine($values[$i].TrimEnd("`r")) }
        else { [Console]::Out.WriteLine('') }
    }
    exit 0
}
catch {
    exit 1
}
