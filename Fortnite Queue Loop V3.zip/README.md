# Fortnite Queue Loop by Krstic

This is a separate AutoHotkey v2 macro limited to 1920×1080. It searches for lobby **PLAY** and results **PLAY AGAIN**, including the shifted position with **STAY WITH TEAM**. Results detection now checks the full button and cropped button text with more color tolerance, and retries a visible button about every 3 seconds if the click does not advance. It ignores the team button.

## Run it

Right-click the ZIP and choose **Extract All**; do not run the script from inside the ZIP. Keep the extracted `images` folder beside the `.ahk` file. Install AutoHotkey v2, open `Fortnite Queue Loop.ahk`, focus Fortnite, then press **F9** to start. Press **F10** to stop. The enabled relaunch failsafe detects when Fortnite closes after it has been running, waits 8 seconds, then asks Epic Games Launcher to reopen it. It retries up to three times and stops retrying if the game will not start. A stable 2-minute run resets the retry count.

A click-through panel shows games completed and session runtime while running. The count increases when the macro finds a new results **PLAY AGAIN** screen.

## Optional Discord webhook

Create a webhook in your Discord server’s **Server Settings → Integrations → Webhooks**, copy its URL, paste it into the macro’s field, and optionally enter a Discord user ID to ping. To copy your ID, enable **User Settings → Advanced → Developer Mode**, then right-click your Discord profile and choose **Copy User ID**. Leave the ID blank to send without a ping. Click **Save**, **Test Photo**, or **Start** to save settings. The webhook URL and user ID are encrypted with Windows DPAPI for your current Windows account and stored under `%LOCALAPPDATA%\FortniteQueueLoop`, outside the extracted macro folder. Click **Save** with both fields blank to erase the saved settings.

Click **Test Photo** to send a screenshot attachment and, if a user ID was entered, a targeted ping. While running, the checked-by-default treasure alert requires the transparent **YOU FOUND** text to match in two consecutive scans before sending a screenshot. It uses a tighter match and ignores the broad PirateShopAccess image to reduce false alerts in ordinary lobby scenes. It can still miss if Fortnite changes the banner or UI scaling. It does not monitor every ordinary weapon, ammo, or ground-item pickup. The macro can also send messages after finished games and a session summary when stopped.

Epic Games documents the launcher deep link used for relaunching Fortnite in its [protocol activation guide](https://assets-unreal2-epic-prod-us2.s3.dualstack.us-east-1.amazonaws.com/original/4X/f/c/4/fc4342c50e1a0abf34943e019ee90bacccc62950.pdf).

The treasure banner reference is cropped from a gameplay screenshot in the [Pro-Gamer.gg Fortnite Pirate Shop guide](https://pro-gamer.gg/fortnite-pirate-shop-guide-best-chest-spots-access-token-free-item-shop-14-days/). Discord file attachments use the webhook’s multipart upload format; targeted pings use Discord’s [`allowed_mentions`](https://discord.com/developers/docs/resources/message#allowed-mentions-object) field.


Optional random keys: enable the checkbox before starting. The macro continuously cycles through Space, W, A, S, and D, holding one key for 1–3 seconds and switching immediately to the next; Space is weighted to occur more often. Settings are remembered on this PC. F11 pauses or resumes the loop and releases any held key while paused; F10 stops it. The stats overlay shows the current held key or countdown.









## Low-squad leave and requeue

The checked-by-default **Leave + requeue when fewer than 2 party members remain** option samples the four squad HUD health-bar slots at the included fixed 1920×1080 positions. When exactly one active squad member is detected for 30 consecutive one-second scans, the macro opens the pause menu, selects **Return to Lobby**, confirms if needed, then clicks lobby **PLAY**. The check pauses on the **WAITING FOR PLAYERS** warm-up screen. Keep the usual Fortnite HUD layout visible; the supplied pixel detector depends on those fixed HUD positions and may need retuning if Fortnite changes its UI.

